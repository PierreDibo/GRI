TP1
==================

# Configuration

* make ou javac *.java
* java TP1 filename.txt

# [Sujet](./tp1.pdf)
